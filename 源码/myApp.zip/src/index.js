import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import '@nutui/nutui-react/dist/style.css'
import '@nutui/nutui-biz/dist/style.css'
import App from './App';
import reportWebVitals from './reportWebVitals';
import { IntlProvider } from "react-intl";
import zhTW from "./locales/zh_TW";
import enJS from "./locales/en_US";
import thai from "./locales/thai";
const handleMessages = lang => {
    let res = null;
	var lan=localStorage.getItem("lang");
    switch (lan) {
      case "zhTW":
        res = zhTW;
        break;
	  case "thai":
		res = thai;
		break;
      case "enUS":
        res = enJS;
        break;
		
      default:
        res = zhTW;
    }
    return res;
  };
 const state = {
        locale: 'zh'
      }
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <IntlProvider
            locale={navigator.language}
            messages={handleMessages()}
          >
    <App/>
  </IntlProvider>
);

 

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
