import React from "react";
import { Tabbar } from '@nutui/nutui-react';
import { Cart, Category, Find, Home, My } from '@nutui/icons-react';
import { Outlet ,useLocation  } from 'react-router-dom';
import { useEffect, useState } from "react";
const App = () => {
	const [activeIndex, setActiveIndex] = useState(2)
	const location = useLocation();
	const [titles, setTitles]=useState([]);
	useEffect(() => {
		
	  var name=location.pathname;
	  var s=name.split("/")[1];
	  console.log(s)
	  if(s==''){
		  window.location.href="/home"
	  }
	  if(s=='my'){
		  setActiveIndex(4)
	  }
	  if(s=='shop'){
	  	  setActiveIndex(1)
	  }
	  if(s=='orderList'){
	  	  setActiveIndex(3)
	  }
	  if(s=='home'){
	  	  setActiveIndex(0)
	  }
	  var lan=localStorage.getItem("lang");
	  switch (lan) {
	    case "zhTW":
	      setTitles({
			  name1:'首頁',
			  name2:'分類',
			  name3:'發現',
			  name4:'訂單',
			  name5:'我',
		  })
	      break;
	    case "thai":
	  	setTitles({
	  				  name1:'หน้าหลัก',
	  				  name2:'หมวดหมู่',
	  				  name3:'ค้นพบ',
	  				  name4:'การสั่งซื้อ',
	  				  name5:'ฉัน',
	  	})
	  	break;
	    case "enUS":
	     setTitles({
	     			  name1:'Home',
	     			  name2:'Sort',
	     			  name3:'Find',
	     			  name4:'Order',
	     			  name5:'My',
	     })
	      break;
	  	
	    default:
	    setTitles({
	    			 name1:'首頁',
	    			 name2:'分類',
	    			 name3:'發現',
	    			 name4:'訂單',
	    			 name5:'我',
	    })
	      
	  }
	}, [])

return (

<div>
	        
	            <Outlet></Outlet>
	        
  <Tabbar  fixed
  defaultValue={0}
      value={activeIndex}
      onSwitch={(value) => {
        setActiveIndex(value)
      }}
  >
    <Tabbar.Item title={titles.name1} onClick={()=>{window.location.href="/home"}} icon={<Home width={20} height={20} />} />
    <Tabbar.Item title={titles.name2} onClick={()=>{window.location.href="/shop"}} icon={<Category width={20} height={20} />} />
    <Tabbar.Item title={titles.name3} onClick={()=>{window.location.href="/shopHome"}} icon={<Find width={20} height={20} />} />
    <Tabbar.Item title={titles.name4} onClick={() =>  window.location.href="/orderList"} icon={<Cart width={20} height={20} />} />
    <Tabbar.Item title={titles.name5} onClick={()=>{window.location.href="/my"}} icon={<My width={20} height={20} />} />
  </Tabbar>
  </div>
)}

export default App;