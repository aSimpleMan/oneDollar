import React, {  FunctionComponent, useCallback, useEffect, useRef, useState } from 'react'
import { VirtualList } from '@nutui/nutui-react';
import { Tabs } from '@nutui/nutui-react';
import { NavBar, Toast } from '@nutui/nutui-react';
import Language from './language'
import { Left } from '@nutui/icons-react';
import { BASE_URL } from './config.js';
import axios from 'axios';

const App =() => {
  const [list, setsourceData] = useState([])
  const [titles, setTitles] = useState([])
  const [tab1value, setTab1value] = useState('0');
  var lan=localStorage.getItem("lang");
  const getData = useCallback(() => {
    const datas = [];
	var token=localStorage.getItem("token");
	axios({
	      method: 'post',
		  withCredentials: true,
		  changeOrigin:true,
		  headers:{'Content-Type':'application/x-www-form-urlencoded'},
		  params:{
		  	'token':token
		  },
	      url: BASE_URL+'/api/user/accountchangelist'
	    }).then(response => {
		 
	      console.log(response.data)
	      if(response.status=='200'){
			
			if(response.data.login.state=='2'){
				window.location.href="/login";
			}else{
				var data=response.data.data.list;
				for (let i = 0; i < data.length; i++) {
					var dty=data[i].accounttype_id
					var typeString;
					if(dty==1){
						switch (lan) {
						  case "zhTW":
						  typeString="下單扣除";
						    break;
						  case "thai":
						   typeString="การหักคำสั่งซื้อ";
							break;
						  case "enUS":
						  typeString="Order deduction";
						    break;
						  default:
						  typeString="下單扣除";
						}
					}
					if(dty==2){
						switch (lan) {
						  case "zhTW":
						  typeString="充值";
						    break;
						  case "thai":
						   typeString="เติมเงิน";
							break;
						  case "enUS":
						  typeString="Recharge";
						    break;
						  default:
						  typeString="充值";
						}
					}
					if(dty==3||dty==4){
						switch (lan) {
						  case "zhTW":
						  typeString="客服操作";
						    break;
						  case "thai":
						   typeString="การดำเนินงานการบริการลูกค้า";
							break;
						  case "enUS":
						  typeString="Customer Service Operations";
						    break;
						  default:
						  typeString="客服操作";
						}
					}
					
				  datas.push({
					  "type":typeString,
					  "c_time":data[i].c_time.date.slice(0,16),
					  "c_money":data[i].c_money,
					  "wallet_after":data[i].wallet_after,
				  })
				}
				setsourceData((list) => {
				  return [...list, ...datas]
				})
				
			}
			
			
	  	}
	});
  }, [])
  useEffect(() => {
    getData()
	
	
	switch (lan) {
	  case "zhTW":
	    setTitles({
			name1:'資金記錄',
			name2:'類型',
			name3:'下單扣除',
			name4:'操作日期',
			name5:'資金流動',
			name6:'餘額',
		})
	    break;
	  case "thai":
		setTitles({
			name1:'บันทึกการระดมทุน',
			name2:'ประเภท',
			name3:'การหักคำสั่งซื้อ',
			name4:'วันที่ดำเนินการ',
			name5:'เงินทุนหมุนเวียน',
			name6:'ยอดคงเหลือ',
		})
		break;
	  case "enUS":
	   setTitles({
	   		name1:'Money Record',
	   		name2:'Type',
	   		name3:'Order deduction',
	   		name4:'Operation date',
	   		name5:'Capital flow',
			name6:'Balance'
	   })
	    break;
		
	  default:
	  setTitles({
	  		name1:'資金記錄',
	  		name2:'類型',
	  		name3:'下單扣除',
	  		name4:'操作日期',
	  		name5:'資金流動',
	  		name6:'餘額',
	  })
	    
	}
  }, [getData])
  
  const itemRender = (data, dataIndex) => {
    return <div><p>{titles.name2} : {data.type}</p>
	<p>{titles.name4} : {data.c_time}</p>
	<p>{titles.name5} : {data.c_money}</p>
	<p>{titles.name6} : {data.wallet_after}</p></div>
  }
  return (<>
  <div>
  <NavBar
      back={ <>
          <Left name="left" color="#979797" />
           </>
      }
      right={
      <span >
          <Language />
      </span>
      }
      onBackClick={(e) =>  window.location.href="/my"}
  >
      <span onClick={(e) =>  Toast.show("标题")}>
      {titles.name1}
      </span>
  </NavBar>
   
         
       
        
		   <div className='nut-virtualList-demo-box  hideScrollbar heigh1'>
			  <VirtualList
				itemHeight={66}
				list={list}
				itemRender={itemRender}
			  />
			</div> 
        
  </div>
    
	</>
  )
}
export default App;
