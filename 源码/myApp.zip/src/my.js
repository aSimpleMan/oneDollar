import  React,{useEffect,useState } from 'react';
import { Avatar } from '@nutui/nutui-react';
import { NavBar,Toast } from '@nutui/nutui-react';
import { Left } from '@nutui/icons-react';
import { Row, Col,Price,Button  ,Notify  } from '@nutui/nutui-react';
import { Message,Right,Addfollow,Order } from '@nutui/icons-react';
import { BASE_URL } from './config.js';
import "./my.css";
import axios from 'axios';
import { FormattedMessage  } from 'react-intl';
import Language from './language'
const App = () => {
	const [data, setData] = useState('')
	const [title, setTitles] = useState('')
	useEffect(() => {
	    init();
		
		var lan=localStorage.getItem("lang");
		switch (lan) {
		  case "zhTW":
		    setTitles({
				name1:'我的',
				name2:'帳戶餘額',
				name3:'可用積分',
				name4:'立即充值',
				name5:'消息',
				name6:'奪寶記錄',
				name7:'資金記錄',
				name8:'參與人數',
				name8:'參與人數',
				name9:'中獎人',
				name10:'請聯系客服線上充值',
				
			})
		    break;
		  case "thai":
			setTitles({
				name1:'ของฉัน',
				name2:'ยอดคงเหลือในบัญชี',
				name3:'คะแนนที่มีอยู่',
				name4:'เติมเงินตอนนี้',
				name5:'ข้อความ',
				name6:'บันทึกการคว้าสมบัติ',
				name7:'บันทึกการระดมทุน',
				name8:'จำนวนผู้เข้าร่วม',
				name9:'ผู้ชนะ',
				name10:'กรุณาติดต่อฝ่ายบริการลูกค้า LINE เพื่อเติมเงิน',
				
			})
			break;
		  case "enUS":
		   setTitles({
		   		name1:'My',
		   		name2:'Account balance',
		   		name3:'Available points',
		   		name4:'Recharge',
		   		name5:'Message',
				name6:'Order Record',
				name7:'Money Record',
				name8:'Already participated',
				name9:'Winner',
				name10:'Please contact customer service for online recharge', 
		   })
		    break;
			
		  default:
		  setTitles({
		  		name1:'我的',
		  		name2:'帳戶餘額',
		  		name3:'可用積分',
		  		name4:'立即充值',
		  		name5:'消息',
		  		name6:'奪寶記錄',
		  		name7:'資金記錄',
		  		name8:'參與人數',
		  		name8:'參與人數',
		  		name9:'中獎人',
		  		name10:'請聯系客服線上充值',
		  })
		    
		}
	  }, []);
	  
	const init = () => {
		var token=localStorage.getItem("token");
		axios({
		      method: 'get',
		      url: BASE_URL+'/api/user/info',
		      params:{
				  'token':token
			  },
		    }).then(response => {
		
		      if(response.status=='200'){
				if(response.data.login.state=='2'){
					window.location.href="/login";
				}else{
					setData(response.data.data)
				}
				console.log(response.data.data);
				
		  		}
		});
	    
	}
	
  return (  <>
      <NavBar
              back={ <>
                  <Left name="left" color="#979797" />
                  <FormattedMessage id="hello" /> </>
              }
              right={
              <span >
                  <Language />
              </span>
              }
              
              onBackClick={(e) =>  window.location.href="/home"}
          >
              <span >
              {title.name1}
              </span>
          </NavBar>
		   <Row class="myMain">
		              <Col span="6">
					  <div class="toux">
		                  <Avatar
		                    size="normal"
		                    src="https://img12.360buyimg.com/imagetools/jfs/t1/143702/31/16654/116794/5fc6f541Edebf8a57/4138097748889987.png"
		                  />
						  </div>
		              </Col>
					  <Col span="12">
					      <span class="nc">{data.account}</span>
					  </Col>
					  <Col span="6">
					     
					  </Col>
		          </Row>
				<Row>
					<Col span="8">
						<div class="main_left">
							<div class="nut-cell__title">
								<span><Price price={data.wallet} size="normal"  thousands /></span>
							</div>
							<div class="nut-cell__description">
							    <span>{title.name2}</span>
							</div>
							 
						</div>
				    
					</Col>
					<Col span="8">
					     <div class="main_left">
					     	 <div class="nut-cell__title">
					     	 	<span>0.00</span>
					     	 </div>
					     	 <div class="nut-cell__description">
					     	     <span>{title.name3}</span>
					     	 </div>
					     </div>
					</Col>
					<Col span="8">
					 <div class="main_left">
						<Button type="primary" onClick={(event: React.MouseEvent) => {
							 Notify.text(title.name10)
						}}>{title.name4}</Button>
					 </div>
					     
					</Col>
				</Row>
      <Row className="class1">
                 <Col span="18">
      				<div class="list" onClick={(e) =>  window.location.href="/message"}>
						<div class="icon">
							 <Message />
						</div>
						<span>{title.name5}</span>
      				</div>
                 </Col>
      				<Col span="6" className="class2">
      					<span class="nc"><Right/></span>
      				</Col>
      					  
             </Row>
			 <Row className="class1 classm">
			            <Col span="18">
			 				<div class="list" onClick={(e) =>  window.location.href="/orderList"}>
			 						<div class="icon">
			 							 <Addfollow />
			 						</div>
			 						<span>{title.name6}</span>
			 				</div>
			            </Col>
			 				<Col span="6" className="class2">
			 					<span class="nc"><Right/></span>
			 				</Col>  
			        </Row> 
					<Row className="class1 classm">
					           <Col span="18">
									<div class="list" onClick={(e) =>  window.location.href="/moneyChangeList"}>
											<div class="icon">
												 <Order />
											</div>
											<span>{title.name7}</span>
									</div>
					           </Col>
									<Col span="6" className="class2">
										<span class="nc"><Right/></span>
									</Col>  
					       </Row>
    </>
  )
}
export default App;
