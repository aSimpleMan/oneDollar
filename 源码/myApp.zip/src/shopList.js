import  React,{useEffect,useState} from 'react';
import { NavBar, Toast,Notify } from '@nutui/nutui-react';
import Language from './language'
import { Category } from '@nutui/nutui-biz';
import  {quickEnterData}  from "./locales/zhShopList.js";
import  {quickEnterData1}  from "./locales/thaiShopList.js";
import { FormattedMessage  } from 'react-intl';
export default function OrderList() {
	
	
	
    const [category, setCategory] = useState();
	const getData = () => {
		var lan=localStorage.getItem("lang");
		switch (lan) {
		  case "zhTW":
		    setCategory(quickEnterData.categoryInfo.category)
		    break;
		  case "thai":
			setCategory(quickEnterData1.categoryInfo.category)
			break;
		  case "enUS":
		    setCategory(quickEnterData.categoryInfo.category)
		    break;
			
		  default:
		  setCategory(quickEnterData.categoryInfo.category)
		    
		}
		console.log(quickEnterData.categoryInfo);
		 
		//setCategory(quickEnterData.categoryInfo.category)
	    // fetch("https://storage.360buyimg.com/nutui/3x/new-categoryData.js")
	    //   .then((response) => response.json())
	    //   .then((res) => {
	    //     setCategory(res.categoryInfo.category)
	    //   })
	    //   .catch((err) => console.log("Oh, error", err));
	  };
    
	
      const onClassifyClick = (index:number)=>{
        console.log('一级分类',index)
		Notify.text("软件升级中");
      }
    
      const onPanelThirdClick = (sku:any)=>{
        console.log('三级分类跳转', sku)
		Notify.text("软件升级中");
      }
    useEffect(() => {
        getData();
      }, []);
      

    return (
	<div>
        <NavBar
            
            right={
            <span >
                <Language />
            </span>
            }
            onBackClick={(e) =>  Toast.show("返回")}
        >
            <span onClick={(e) =>  Toast.show("标题")}>
            <FormattedMessage id="top1" />
            </span>
        </NavBar>
		<Category category={category} onClick={onClassifyClick} onPanelThirdClick={onPanelThirdClick}></Category>
		</div>
    )
}

