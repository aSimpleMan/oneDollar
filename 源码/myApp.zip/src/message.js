import React, { useEffect } from 'react';
import '@chatui/core/es/styles/index.less';
import Chat, { Bubble, useMessages } from '@chatui/core';
import '@chatui/core/dist/index.css';
import { BASE_URL } from './config.js';
import axios from 'axios';

const initialMessages = [
  // {
  //   type: 'text',
  //   content: { text: '主人好，我是智能助理，你的贴心小助手~' },
  //   user: { avatar: '//gw.alicdn.com/tfs/TB1DYHLwMHqK1RjSZFEXXcGMXXa-56-62.svg' },
  // },
];
var text1;
var lan=localStorage.getItem("lang");
		switch (lan) {
		case "zhTW":
      	text1="智能客服"
		    break;
		  case "thai":
		  text1="ฝ่ายบริการลูกค้า"
			break;
		  case "enUS":
		  text1="Customer Service"
		 
		    break;
		 default:
		 text1="智能客服"
		
}
const navbar= 
      {
		  title:text1,
          leftContent: {
			icon:'chevron-left'
		},
       
      }

const toolbar= [
      {
        // type: 'image',
        // icon: 'image',
        // title: '相册',
      }
]
// 默认快捷短语，可选
const defaultQuickReplies = [
  {
    icon: 'message',
    name: '联系人工服务',
    isNew: true,
    isHighlight: true,
  }
];
var socket;
var tokens;
export default function() {
  // 消息列表
  const { messages, appendMsg, setTyping } = useMessages(initialMessages);
  
      useEffect(() => {
      	var token=localStorage.getItem("token");
		axios({
		      method: 'post',
			  params:{
			  	'token':token
			  },
		      url: BASE_URL+'/api/user/createimtoken'
		    }).then(response => {
			 
		      console.log(JSON.stringify(response.data))
		      if(response.status=='200'){
		      				if(response.data.login.state=='2'){
		      					
		      				}else{
		      					tokens=response.data.data.im_token;
								//socket = new WebSocket("ws://192.168.2.128:20000?token="+encodeURIComponent(tokens));
								socket = new WebSocket("ws://27.124.53.116:20000?token="+encodeURIComponent(tokens));
								
								socket.onopen = function(event) { console.log("WebSocket 连接已建立"); }; 
								// 监听接收到消息事件 
								socket.onmessage = function(event) { 
									console.log("接收到消息：" + event.data); 
									var res=JSON.parse(event.data)
									appendMsg({
									  type: 'text',
									  user: { avatar: '//gw.alicdn.com/tfs/TB1DYHLwMHqK1RjSZFEXXcGMXXa-56-62.svg' },
									  content: { text: res.content },
									});
								}; 
								socket.onclose = function(){
								           
										   setTimeout(() => {
										   	
										     window.location.href="/message"
										   }, 3000);
								    }
		      				}			
		    }
		});
}, [])
      	    
        
      
  // 发送回调
  function handleSend(type, val) {
	  var s={'token':tokens,
	'type':1,
	'content':val};
	socket.send(JSON.stringify(s));
    if (type === 'text' && val.trim()) {
      // TODO: 发送请求
      appendMsg({
        type: 'text',
        content: { text: val },
        position: 'right',
      });

      

      
    }
  }
  

  // 快捷短语回调，可根据 item 数据做出不同的操作，这里以发送文本消息为例
  function handleQuickReplyClick(item) {
    handleSend('text', item.name);
  }
  function onNavbarClick(item) {
    handleSend('text', item.name);
  }

  function renderMessageContent(msg) {
    const { type, content } = msg;

    // 根据消息类型来渲染
    switch (type) {
      case 'text':
        return <Bubble content={content.text} />;
      case 'image':
        return (
          <Bubble type="image">
            <img src={content.picUrl} alt="" />
          </Bubble>
        );
      default:
        return null;
    }
  }
 function onToolbarClick(item, ctx) {
      // 如果点的是“相册”
	 
      if (item.type === 'image') {
		  const input = document.createElement('input')
		      //选择上传文件
		    input.type = 'file'
		      //接受文件类型
		    input.accept = 'image/*'
		    input.click()
		    input.onchange = (ctx) => {
		      console.log('inputfiles',input.files);
		    
		      if (input.files) {
		        const file = input.files[0]
				appendMsg({
				  type: 'image',
				  content: { picUrl: URL.createObjectURL(file) },
				  position: 'right',
				});
		      }
		    }
			
		 
        // ctx.util.chooseImage({
        //   // multiple: true, // 是否可多选
        //   success(e) {
        //     if (e.files) { // 如果有 h5 上传的图
        //       const file = e.files[0];
        //       // 先展示图片
        //       ctx.appendMessage({
        //         type: 'image',
        //         content: {
        //           picUrl: URL.createObjectURL(file)
        //         },
        //         position: 'right'
        //       });

              

        //     } else if (e.images) { // 如果有 app 上传的图
        //       // ..与上面类似
        //     }
        //   },
        // });
      }
    }
	setTimeout(() => {
		
	  var btn = document.getElementsByClassName("Navbar-left")[0];
		btn.onclick = function(){
		    window.location.href="/my";
		};
	}, 1000);
	function onInputFocus(){
		// var btn = document.getElementsByClassName("MessageList")[0];
		// var scrollHeight=btn.scrollHeight;
		// var height=btn.style.height;
		// console.log("scrollHeight="+scrollHeight+",height="+height)
		
		// btn.scrollTop = btn.scrollHeight-40;
	}
  return (<>
    <Chat
	onInputFocus={onInputFocus}
      navbar={navbar}
	  onNavbarClick={onNavbarClick}
      messages={messages}
      renderMessageContent={renderMessageContent}
      quickReplies={defaultQuickReplies}
      onQuickReplyClick={handleQuickReplyClick}
      onSend={handleSend}
	  toolbar={toolbar}
	  onToolbarClick={onToolbarClick}
    />
	
	</>
  );
}