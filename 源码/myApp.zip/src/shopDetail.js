import  React,{useEffect,useState } from 'react';
import { NavBar, Toast,Notify  } from '@nutui/nutui-react';
import { Left } from '@nutui/icons-react';
import Language from './language'
import { Image } from '@nutui/nutui-react';
import { Cell } from '@nutui/nutui-react';
import { BASE_URL } from './config.js';
import { Progress ,CountDown ,Button,Price   } from '@nutui/nutui-react';
import { InputNumber, ConfigProvider,ShortPassword ,NumberKeyboard  } from '@nutui/nutui-react';
import axios from 'axios';
import "./shopDetail.css"
export default function OrderList() {
	const [data, setData] =  useState([]);
	const [cnt, setCnt] =  useState('1');
	const [shopPrice, setshopPrice] =  useState([]);
	const [sumshopPrice, setsumshopPrice] =  useState([]);
	const [visible1, setVisible1] = useState(false)
	const [visible, setVisible] = useState(false)
	const [value, setValue] = useState('')
	const [activity_id, setActivity_id] = useState('')
	const [title, setTitle] = useState('')
	const [isZJ, setIsZJ] = useState()
	const [stpwdcunt, setStpwdcunt] = useState('')
	const [pwd1, setPwd1] = useState('')
	const [pwd2, setPwd2] = useState('')
	const [joins, setJoins] = useState('')
	const [join_count, setJoin_count] = useState('')
	const [titles, setTitles] =  useState([]);
	const onChange = (v: string) => {
		
	    setValue((value) => value + v);
		var pwd=value + v;
		
		if(pwd.length==6){
			setVisible1(false);
			if(pwd1){
				setPwd2(pwd);
				setVisible(false);
				if(pwd1!=pwd){
					Notify.text(titles.name6);
					setPwd1('');
					setPwd2('');
					setValue('');
					
					return false;
				}
				setIsZJ(true);
				if(pwd1&&pwd){
					//设置资金密码
					var token=localStorage.getItem("token");
					axios({
					      method: 'get',
					      url: BASE_URL+'/api/user/fundpin',
					      params:{
							  'token':token,
							  "new_fund_pin":pwd1,
							  "new_fund_pin_confirmed":pwd
						  },
					    }).then(response => {
					      if(response.data.data.state=='1'){
							console.log(response.data.data);
							submitFrom();
					  		}else{
								Notify.text(response.data.data.text);
								setValue('');
							}
					});
				}
				
			}else{
				if(!isZJ){
					
					setPwd1(pwd);
					setValue('');
					setTitle(titles.name7);
					setVisible1(true)
				}else{
					setVisible(false);
					//检查资金密码
					var token=localStorage.getItem("token");
					axios({
					      method: 'get',
					      url: BASE_URL+'/api/user/checkfundpin',
					      params:{
							  'token':token,
							  "fund_pin":pwd
						  },
					    }).then(response => {
					      if(response.data.data.state=='1'){
							console.log(response.data.data);
							submitFrom();
					  		}else{
								Notify.text(titles.name13);
								setValue('');
							}
					});
					
				}
			}
			
			
			
			
		}
		
		console.log(value + v);
	}
	// 提交订单
	const submitFrom = () => {
		setValue('');
		var token=localStorage.getItem("token");
		axios({
		      method: 'get',
		      url: BASE_URL+'/api/good/createord',
		      params:{
				  'token':token,
				  "activity_id":activity_id,
				  "cnt":cnt
			  },
		    }).then(response => {
		      if(response.data.data.state=='1'){
				Notify.text(titles.name8);
				setTimeout(() => {
				  
				  window.location.href="/orderList"
				}, 2000);
		  		}else{
					Notify.text(response.data.data.text);
					
				}
		});
	}
	const onSub = () => {
		var token=localStorage.getItem("token");
		axios({
		      method: 'get',
		      url: BASE_URL+'/api/user/info',
		      params:{
				  'token':token
			  },
		    }).then(response => {
		
		      if(response.status=='200'){
				if(response.data.login.state=='2'){
					window.location.href="/login";
				}else if(response.data.data.wallet>sumshopPrice||response.data.data.wallet==sumshopPrice){
					if(response.data.data.have_fund_ping!=1){
						setIsZJ(false)
						setTitle(titles.name9);
					}else{
						setIsZJ(true)
						setTitle(titles.name7);
					}
					setVisible1(true);
				}else{
					Notify.text(titles.name10);
				}
				console.log(response.data.data);
				
		  		}
		});
	    
	}
	const onDelete = () => {
	    setValue((value) => value.slice(0, -1))
	}
	const customTheme = {
	    nutuiInputnumberButtonWidth: '30px',
	    nutuiInputnumberButtonHeight: '30px',
	    nutuiInputnumberButtonBorderRadius: '2px',
	    nutuiInputnumberButtonBackgroundColor: `#f4f4f4`,
	    nutuiInputnumberInputHeight: '30px',
	    nutuiInputnumberInputMargin: '0 2px',
	}
   
	const getData = () => {
	    var json=localStorage.getItem("shopDetail");
		var jsonobj=JSON.parse(json);
		
		setActivity_id(jsonobj.activity_id);
		var pr=parseInt(jsonobj.price/jsonobj.set_ord);
		setshopPrice(pr);
		setsumshopPrice(pr)
		console.log(JSON.parse(json));
		setData(jsonobj);
		
		var Join=jsonobj.join_count/jsonobj.set_ord;
		setJoin_count(jsonobj.join_count)
		setJoins(Join*100)
		console.log("setJoins="+setJoins)
		//百分比参与人数
	  };
    
	
    useEffect(() => {
        getData();
		var lan=localStorage.getItem("lang");
		switch (lan) {
		  case "zhTW":
		    setTitles({
				name1:'期数',
				name2:'參與人數',
				name3:'活動結束',
				name4:'單筆金額',
				name5:'總金額',
				name6:'2次資金密碼設定不一樣',
				name7:'請確認資金密碼',
				name8:'下单成功',
				name9:'請设置資金密码',
				name10:'餘額不足，聯系客服充值',
				name11:'提交',
				name12:'您使用了虛擬資產，請進行驗證',
				name13:'資金密碼錯誤!',
				
			})
		    break;
		  case "thai":
			setTitles({
				name1:'จำนวนงวด',
				name2:'จำนวนผู้เข้าร่วม',
				name3:'สิ้นสุด',
				name4:'จำนวนรายการเดียว',
				name5:'ยอดรวม',
				name6:'รหัสผ่านไม่เหมือนกัน 2 ครั้ง',
				name7:'กรุณายืนยันรหัสผ่านกองทุน',
				name8:'สั่งซื้อสำเร็จ',
				name9:'ตั้งรหัสผ่านกองทุน',
				name10:'ยอดคงเหลือไม่เพียงพอติดต่อฝ่ายบริการลูกค้าเพื่อเติมเงิน',
				name11:'สั่งซื้อสินค้า',
				name12:'คุณใช้สินทรัพย์เสมือนโปรดตรวจสอบ',
				name13:'รหัสผ่านกองทุนผิดพลาด!',
				
			})
			break;
		  case "enUS":
		   setTitles({
		   		name1:'Number',
		   		name2:'Join',
		   		name3:'End Time',
		   		name4:'Unit-price',
		   		name5:'Total amount',
				name6:'Two different passwords',
				name7:'Please confirm the fund password',
				name8:'Success',
				name9:'Set fund password',
				name10:'Insufficient balance, please recharge', 
				name11:'Submit',
				name12:'You have used virtual assets, please verify',
				name13:'Money password error!',
				
		   })
		    break;
			
		  default:
		  setTitles({
		  		name1:'期数',
		  		name2:'參與人數',
		  		name3:'活動結束',
		  		name4:'單筆金額',
		  		name5:'總金額',
		  		name6:'2次資金密碼設定不一樣',
		  		name7:'請確認資金密碼',
		  		name8:'下单成功',
		  		name9:'請设置資金密码',
		  		name10:'餘額不足，聯系客服充值',
		  		name11:'提交',
		  		name12:'您使用了虛擬資產，請進行驗證',
		  		name13:'資金密碼錯誤!',
		  })
		    
		}
      }, []);
    const onChanges = (value: string | number) => {
        setCnt(value);
       
        setsumshopPrice(Number(value)*shopPrice)
         
      }
	
    return (
	<div>
        <NavBar
            back={ <>
                <Left name="left" color="#979797" />
                 </>
            }
            right={
            <span >
                <Language />
            </span>
            }
            onBackClick={(e) =>  window.location.href="/home"}
        >
            <span onClick={(e) =>  Toast.show("标题")}>
            {data.good_name1}
            </span>
        </NavBar>
		
		<div class="demo">
			<h2>{titles.name1} : {data.activity_qh}</h2>
			<Image src={ BASE_URL+data.good_img1} width="100%" />
			<div>
			 <Cell>
			        <div>{data.good_desc1}></div>
					
					
			    </Cell>
				<Cell><div>{data.good_desc2}</div></Cell>
				<Cell><div>{data.good_desc3}</div></Cell>
			</div>
			<Progress percent={joins} strokeWidth="15" showText />
			 <Cell className="cb" title={<span>{titles.name2}:<span>{join_count}</span></span>} 
			 extra={
				 <div className='per'>{titles.name3}:
				 <CountDown endTime={new Date(data.opening_time).valueOf()} format="DD天HH时mm分" />
				 </div>
				 } />
			 <Cell className="cb" title={
				 <div>{titles.name4}:
				 <Price price={shopPrice} size="normal"  thousands />
				 </div>
				 
			 }
			 extra={ 
				 <ConfigProvider theme={customTheme}>
					<InputNumber defaultValue={1} onChange={onChanges} max="5"/>
				  </ConfigProvider>
				} />
			 <Cell className="cb" title={
				 <div>{titles.name5}:
				 <Price price={sumshopPrice} size="normal"  thousands />
				 </div>
				 
			 } extra={<Button type="primary" onClick={onSub}>{titles.name11}</Button>} />
			 <ShortPassword
			         visible={visible1}
			         value={value}
					 title={title}
					 tips=" "
					 description={titles.name12}
			         onFocus={() => setVisible(true)}
			         onClose={() => {
			           setVisible1(false)
			           setValue('')
			         }}
			         onChange={(value) => setValue(value)}
			       />
			       <NumberKeyboard
			         visible={visible}
			         onClose={() => setVisible(false)}
			         onChange={onChange}
			         onDelete={onDelete}
			       />
		</div>
		</div>
    )
}

