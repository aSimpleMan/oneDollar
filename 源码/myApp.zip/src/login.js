import React, { useState, useEffect } from "react";
import { Login } from '@nutui/nutui-biz';
import {Input } from "@nutui/nutui-react";
import { Dialog } from '@nutui/nutui-react';
import { BASE_URL } from './config.js';
import axios from 'axios';
import Language from './language'
import { NavBar } from '@nutui/nutui-react';
import { Left } from '@nutui/icons-react';
const App = () => {
	var lan=localStorage.getItem("lang");
	var accountPlaceholder;
	var passwordPlaceholder;
	switch (lan) {
	  case "zhTW":
	    accountPlaceholder='請輸入帳號';
		passwordPlaceholder="請輸入密碼";
		
	    break;
	  case "thai":
		accountPlaceholder='กรุณากรอกหมายเลขบัญชี';
		passwordPlaceholder="กรุณากรอกรหัสผ่าน";
		break;
	  case "enUS":
	    accountPlaceholder="Please enter an account";
	    passwordPlaceholder="Please enter Password";
	   
	    break;
		
	  default:
	  accountPlaceholder='請輸入帳號';
	  passwordPlaceholder="請輸入密碼";
	    
	}
  const [formParams2, setformParams2] = useState({
    account: "",
    accountPlaceholder: accountPlaceholder,
    accountErrorText: "",
    password: "",
	passwordPlaceholder: passwordPlaceholder,
    passwordErrorText: "",
    isShowPwdInput: true,
  });
  const [isDisable, setIsDisable] = useState(true);
  const [account, setAccount] = useState("");
  const [password, setPassword] = useState("");
  const [titles, setTitles] = useState([]);
  const [customInput, setCustomInput] = useState("");
  const onChange = (value: any, tag: string) => {
    console.log(tag, value);
    if (tag === "account") {
      setAccount(value);
    }
	if (tag === "password") {
	  setPassword(value);
	}
  };
 
  useEffect(() => {
    if (account.length > 2 && account.length < 14 &&password.length>5&&password.length<15) {
      setIsDisable(false);
    } else {
      setIsDisable(true);
    }
	var lan=localStorage.getItem("lang");
	switch (lan) {
	  case "zhTW":
	    setTitles({
			name1:'提示',
			name2:'請輸入正確的驗證碼!',
			name3:'確認',
			name4:'账户不存在!',
			name5:'密码错误!',
			name6:'用戶登錄',
			name7:'新用戶註冊',
			name8:'登錄',
			
			
		})
	    break;
	  case "thai":
		setTitles({
			name1:'เคล็ดลับ',
			name2:'ยืนยัน!',
			name3:'ยืนยัน',
			name4:'ไม่มีบัญชี!',
			name5:'รหัสผ่านไม่ถูกต้อง!',
			name6:'เข้าสู่ระบบผู้ใช้',
			name7:'ลงทะเบียนผู้ใช้ใหม่',
			name8:'เข้าสู่ระบบ',
			
			
		})
		break;
	  case "enUS":
	   setTitles({
	   		name1:'Prompt',
	   		name2:'Please enter the correct verification code!',
	   		name3:'Ok',
	   		name4:'Account does not exist!',
	   		name5:'Password Error',
			name6:'User Login',
			name7:'Registration',
			name8:'Login',
			
	   })
	    break;
		
	  default:
	  setTitles({
	  		name1:'提示',
	  		name2:'請輸入正確的驗證碼!',
	  		name3:'確認',
	  		name4:'账户不存在!',
	  		name5:'密码错误!',
	  		name6:'用戶登錄',
	  		name7:'新用戶註冊',
	  		name8:'登錄',
	  })
	    
	}
  }, [account, customInput]);
  const queryLogin = (formData: any) => {
  	  
  	  console.log("setCustomInput", customInput);
      console.log("login", formData);
  	  if(customInput!="t1tx2"){
  		Dialog.alert({
  		    title: titles.name1,
  		    content: titles.name2,
  		    hideCancelButton: true,
  		    confirmText: titles.name3
  		});
  	  }else{
  		  axios({
  		        method: 'post',
  		        url: BASE_URL+'/api/user/login',
  		        params:{
  					account:formData.account,
  					password:formData.password
  				},
  		      }).then(response => {
  		        console.log("response="+response);
  		        if(response.status=='200'){
  					if(response.data.data.state=='1'){
						localStorage.setItem("token",response.data.token);
						Dialog.confirm({
						            content: 'Success',
						          });
						          setTimeout(() => {
						            window.location.href="/home";
						          }, 2000);
  					}else if(response.data.data.state=='2'){
  						Dialog.alert({
  						    title: titles.name1,
  						    content: titles.name4,
  						    hideCancelButton: true,
  						    confirmText: titles.name3
  						});
  					}else{
  						Dialog.alert({
  						    title: titles.name1,
  						    content: titles.name5,
  						    hideCancelButton: true,
  						    confirmText: titles.name3
  						});
  					}
  				}
  		      });
  	  }
  	  
  };
  return (<>
  <NavBar
          back={ <>
              <Left name="left" color="#979797" />
               </>
          }
          right={
          <span >
              <Language />
          </span>
          }
          
          onBackClick={(e) =>  window.location.href="/home"}
      >
          <span >
          {titles.name6}
          </span>
      </NavBar>
    <Login
	    loginButtonText={titles.name8}
        formParams={formParams2}
        title={titles.name6}
        loginType="pwd"
        onInputChange={onChange}
        isHideSwitchBtn={true}
		onLoginBtnClick={queryLogin}
        loginButtonDisable={isDisable}
		hasForgetPassWord={false}
        onInputClear={(tag) => {
            if (tag === "account") {
              setAccount("");
            }
        }}
        slotInput={
          <div className={`nb-login__input-wrap`}>
            <div className="nb-login__input-item">
              <Input
                className="nut-input-text"
                border={false}
                defaultValue={customInput}
                placeholder={titles.name2}
                type="text"
                clearable
                onChange={(value) => {
                  setCustomInput(value);
                }}
                onClear={() => {
                  setCustomInput("");
                }}
              />
              <div className="nb-login__code-box">
                <img
                  style={{ width: "65px", height: "30px" }}
                  src="https://img12.360buyimg.com/imagetools/jfs/t1/211415/19/9275/14512/61924b82E09366437/cc5cc7297b9073ae.jpg"
                />
              </div>
            </div>
          </div>
        }
        slotBottom={
          <div onClick={()=>{window.location.href="/register"}}
            style={{
              color: "#006FFF",
              textAlign: "center",
              fontSize: "14px",
            }}
          >
            {titles.name7}
          </div>
        }
        /></>
  );
};
export default App;