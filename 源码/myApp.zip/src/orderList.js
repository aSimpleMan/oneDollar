import  React,{useEffect,useState } from 'react';
import { NavBar, Toast } from '@nutui/nutui-react';
import Language from './language'
import { Left } from '@nutui/icons-react';
import { BASE_URL } from './config.js';
import { Tabs } from '@nutui/nutui-react';
import axios from 'axios';
import { Progress, Cell } from '@nutui/nutui-react';
import { Price } from "@nutui/nutui-react";
import { ProductFeed } from "@nutui/nutui-biz";
import { FormattedMessage  } from 'react-intl';
import "./orderlist.css";
const App = () => {
	const [data, setData] =  useState([]);
	const [data1, setData1] =  useState([]);
	const [data2, setData2] =  useState([]);
	const [tab1value, setTab1value] = useState('0');
	const [listSingle, setListSingle] = useState([]);
	const [listSingle1, setListSingle1] = useState([]);
	const [listSingle2, setListSingle2] = useState([]);
	const [hasMoreSingle, setHasMoreSingle] = useState(true);
	const [titles, setTitles] =  useState([]);
	useEffect(() => {
	    initData();
		var lan=localStorage.getItem("lang");
		switch (lan) {
		  case "zhTW":
		    setTitles({
				name1:'進行中',
				name2:'已開獎',
				name3:'已中獎',
				name4:'期號',
				name5:'訂單號',
				name6:'下單時間',
				name7:'開獎時間',
				name8:'參與人數',
				name8:'參與人數',
				name9:'中獎人',
			})
		    break;
		  case "thai":
			setTitles({
				name1:'กำลังดำเนินการ',
				name2:'ออกรางวัลแล้ว',
				name3:'ชนะรางวัล',
				name4:'หมายเลข',
				name5:'การสั่งซื้อ',
				name6:'เวลาสั่งซื้อ',
				name7:'การออกรางวัล',
				name8:'จำนวนผู้เข้าร่วม',
				name9:'ผู้ชนะ',
			})
			break;
		  case "enUS":
		   setTitles({
		   		name1:'In progress',
		   		name2:'Awarded',
		   		name3:'Winning',
		   		name4:'ISSUE',
		   		name5:'No',
				name6:'Creat',
				name7:'Open',
				name8:'Already participated',
				name9:'Winner',
					  
		   })
		    break;
			
		  default:
		  setTitles({
		  		name1:'進行中',
		  		name2:'已開獎',
		  		name3:'已中獎',
		  		name4:'期號',
		  		name5:'訂單號',
		  		name6:'下單時間',
		  		name7:'開獎時間',
				name8:'參與人數',
				name9:'中獎人',
		  })
		    
		}
	  }, []);
	  const init = () => {
	    for (let i = 0; i < data.length; i++) {
	      listSingle.push(data[i])
	    }
	    setListSingle([...listSingle])
		for (let i = 0; i < data1.length; i++) {
		  listSingle1.push(data1[i])
		}
		setListSingle1([...listSingle1])
		for (let i = 0; i < data2.length; i++) {
		  listSingle2.push(data2[i])
		}
		setListSingle2([...listSingle2])
	  }
    const initData = () => {
    	var token=localStorage.getItem("token");
    	axios({
    	      method: 'get',
    	      url: BASE_URL+'/api/good/orderlist',
    	      params:{
    			  'token':token
    		  },
    	    }).then(response => {
    	
    	      if(response.status=='200'){
    			if(response.data.login.state=='2'){
    				window.location.href="/login";
    			}else{
					var list=response.data.data.list;
					
					for(var i = 0; i < list.length; i++) {
						if(list[i].state==1){
							data.push({
							  id: i ,
							  imgUrl: BASE_URL+list[i].good_img1,
							  name: list[i].good_name1,
							  desc: list[i].good_name2,
							  join_count: list[i].join_count,
							  price: list[i].price,
							  paymoney: list[i].paymoney,					
							  activity_qh: list[i].activity_qh,
							  ord_no: list[i].ord_no,
							  opening_time:list[i].opening_time.slice(0,10),
							  c_time: list[i].c_time.date.slice(0,16),
							  baifen:Number(100-list[i].join_count/list[i].set_ord*100)
							})
						}
						if(list[i].state==2){
							data1.push({
							  id: i ,
							  imgUrl: BASE_URL+list[i].good_img1,
							  name: list[i].good_name1,
							  desc: list[i].good_name2,
							  join_count: list[i].join_count,
							  price: list[i].price,
							  paymoney: list[i].paymoney,					
							  activity_qh: list[i].activity_qh,
							  ord_no: list[i].ord_no,
							  opening_time:list[i].opening_time.slice(0,10),
							  c_time: list[i].c_time.date.slice(0,16),
							  winner_account:list[i].winner_account,
							  baifen:Number(100-list[i].join_count/list[i].set_ord*100)
							})
						}
						if(list[i].state==2&&list[i].user_id==list[i].winner_id){
							data2.push({
							  id: i ,
							  imgUrl: BASE_URL+list[i].good_img1,
							  name: list[i].good_name1,
							  desc: list[i].good_name2,
							  join_count: list[i].join_count,
							  price: list[i].price,
							  paymoney: list[i].paymoney,					
							  activity_qh: list[i].activity_qh,
							  ord_no: list[i].ord_no,
							  opening_time:list[i].opening_time.slice(0,10),
							  c_time: list[i].c_time.date.slice(0,16),
							  winner_account:list[i].winner_account,
							  baifen:Number(100-list[i].join_count/list[i].set_ord*100)
							})
						}
					 
					}
					init();
    			}
    			console.log(response.data.data);
    			
    	  		}
    	});
        
    }
	const loadMore = (list: any) => {
	 
	}
	  
	const loadMoreSingle = (done: () => void) => {
	 
	}
	  
	const handleClick = (item: object, index: number) => {
	 
	}
	  
	const handleImageClick = (item: object, index: number) => {
	  console.log("click image", item, index)
	}
	  
	const customProductSingle = (item: any) => {
		
	  return (
	    <>
	      <div className="name-box top">
	        {item.name}
	      </div>
		  <div className="name-box">
		    {titles.name4} : {item.activity_qh}
		  </div>
		  <div className="name-box">
		    {titles.name5} : {item.ord_no}
		  </div>
		  <div className="name-box">
		     {titles.name6} : {item.c_time}
		  </div>
		  <div className="name-box">
		     {titles.name7} : {item.opening_time}
		  </div>
		  
		  <div className="name-box">
		    {titles.name8}  : {item.join_count}
		  </div>
		  <div className="name-box">
		  <div className="price">
		    <Price price={item.paymoney} /><Price price={item.price} thousands line/>
		  </div>
		   
		  </div>
	      
	      <div className="bottom">
	        <div className="price-box">
			<FormattedMessage id="home4" />
	          <Cell>
	                <Progress percent={item.baifen} strokeWidth="5" showText />
	              </Cell>
	        </div>
	      </div>
	    </>
	  )
	}
	const customProductSingle1 = (item: any) => {
		
	  return (
	    <>
	      <div className="name-box top">
	        {item.name}
	      </div>
		  <div className="name-box">
		    {titles.name4} : {item.activity_qh}
		  </div>
		  <div className="name-box">
		    {titles.name5} : {item.ord_no}
		  </div>
		  <div className="name-box">
		     {titles.name6} : {item.c_time}
		  </div>
		  <div className="name-box">
		     {titles.name7} : {item.opening_time}
		  </div>
		  
		  <div className="name-box">
		    {titles.name8}  : {item.join_count}
		  </div>
		  <div className="name-box zhong">
		    {titles.name9}  : {item.winner_account}
		  </div>
		  
		  <div className="name-box">
		  <div className="price">
		    <Price price={item.paymoney} /><Price price={item.price} thousands line/>
		  </div>
		   
		  </div>
	    </>
	  )
	}
    return ( <>
        <NavBar
            back={ <>
                <Left name="left" color="#979797" />
                 </>
            }
            right={
            <span >
                <Language />
            </span>
            }
            onBackClick={(e) =>  window.location.href="/my"}
        >
            <span onClick={(e) =>  Toast.show("标题")}>
            <FormattedMessage id="order1" />
            </span>
        </NavBar>
		<Tabs value={tab1value} onChange={(value) => {
		        setTab1value(value)
		      }}>
		        <Tabs.TabPane title={titles.name1}> 
				<div className="demo product-feed-demo orderlist">
					
				  <ProductFeed
				    
				    className="product-feed-demo2 cx"
				    data={listSingle}
				    infiniteloadingProps={{
				      hasMore: hasMoreSingle,
				      onLoadMore: loadMoreSingle
				    }}
				    customProduct={customProductSingle}
				    col={1}
				    imgUrl="imgUrl"
				    imgWidth="100"
				    imgHeight="100"
				    onClick={handleClick}
				    onImageClick={handleImageClick}
				  />
				</div>
				</Tabs.TabPane>
		        <Tabs.TabPane title={titles.name2}>
				<div className="demo product-feed-demo orderlist">
					
				  <ProductFeed
				    
				    className="product-feed-demo2 cx"
				    data={listSingle1}
				    infiniteloadingProps={{
				      hasMore: hasMoreSingle,
				      onLoadMore: loadMoreSingle
				    }}
				    customProduct={customProductSingle1}
				    col={1}
				    imgUrl="imgUrl"
				    imgWidth="100"
				    imgHeight="100"
				    onClick={handleClick}
				    onImageClick={handleImageClick}
				  />
				</div>
				</Tabs.TabPane>
		        <Tabs.TabPane title={titles.name3}> 
				 <div className="demo product-feed-demo orderlist">
				 	
				   <ProductFeed
				     
				     className="product-feed-demo2 cx"
				     data={listSingle2}
				     infiniteloadingProps={{
				       hasMore: hasMoreSingle,
				       onLoadMore: loadMoreSingle
				     }}
				     customProduct={customProductSingle1}
				     col={1}
				     imgUrl="imgUrl"
				     imgWidth="100"
				     imgHeight="100"
				     onClick={handleClick}
				     onImageClick={handleImageClick}
				   />
				 </div>
				 </Tabs.TabPane>
		      </Tabs>
		 </>
    )
}
export default App;

