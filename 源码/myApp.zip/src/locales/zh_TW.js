const zhTW = {
  hello: "首頁",
  personalCenter: "個人中心",
  logout: "退出登錄",
  top1:'商城',
  home4:'庫存',
  home1:"用戶1872***21，抽中1000元代金券。用戶1872***21，抽中1000元代金券.用戶1872***21，抽中1000元代金券",
  home2:"商品導航",
  home3:"活動商品",
  order1:"訂單詳情",
  
};
export default zhTW;
