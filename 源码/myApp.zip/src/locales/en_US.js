const enUS = {
  hello: "Home",
  personalCenter: "Personal center",
  logout: "Sign out",
  top1:'Shopping',
  home4:'Inventory',
  home1:"User 1542**2311 won a 2000 yuan voucher,User 1542**2311 won a 2000 yuan voucher,User 1542**2311 won a 2000 yuan voucher,",
  home2:"Product navigation",
  home3:"Event merchandise",
  order1:"Order Info",
};
export default enUS;

