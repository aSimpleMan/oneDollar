export const quickEnterData1 = [
  {
    displayName: "ลด50%พื้นที่",
    imageUrl:
      "https://img10.360buyimg.com/imagetools/s100x100_jfs/t1/171408/20/5251/89724/601919feE621f66a5/79fd92576b72cfd4.gif",
  },
  {
    displayName: "โทรศัพท์เคลื่อนที่",
    imageUrl:
      "https://img12.360buyimg.com/imagetools/s100x100_jfs/t1/135346/37/5276/9667/5f1a50a3E51cf1d21/2831b07712127aaa.png",
  },
  {
    displayName: "ข้าว แป้ง ธัญพืช และน้ำมัน",
    imageUrl:
      "https://img30.360buyimg.com/imagetools/s100x100_jfs/t1/112915/31/1239/9586/5e9586eaE549f1ecb/75ee4f10fdb43a1d.png",
  },
  {
    displayName: "อาหารสดตามฤดูกาล",
    imageUrl:
      "https://img12.360buyimg.com/imagetools/s100x100_jfs/t1/128638/35/7916/14107/5f1a50a3E316b5020/e25dd3e7d15c835d.png",
  },
  {
    displayName: "เครื่องดื่ม",
    imageUrl:
      "https://img11.360buyimg.com/imagetools/s100x100_jfs/t1/126267/19/7965/10474/5f1a50a3E9dbf8c1e/1ccdc3b1f6f14fe7.png",
  },
  {
    displayName: "ภาชนะปรุงอาหาร",
    imageUrl:
      "https://img20.360buyimg.com/imagetools/s100x100_jfs/t1/136473/9/5269/10071/5f1a50a3E211837ab/88345f88c8242cd3.png",
  },
  {
    displayName: "ความงามและการดูแลผิว",
    imageUrl:
      "https://img10.360buyimg.com/imagetools/s100x100_jfs/t1/142203/8/3785/10276/5f1a50a3E7b0efbc5/b156c58c52dc734d.png",
  },
  {
    displayName: "ผลิตภัณฑ์กระดาษทำความสะอาด",
    imageUrl:
      "https://img11.360buyimg.com/imagetools/s100x100_jfs/t1/138185/13/3701/9381/5f1a50a3Ea36e2578/ad39b6bd9007c009.png",
  },
  {
    displayName: "ผ้าปูเตียง",
    imageUrl:
      "https://img11.360buyimg.com/imagetools/s100x100_jfs/t1/122764/9/7920/11265/5f1a50a3Ea5580ddb/7dd7b2b5fc497e4b.png",
  },
  {
    displayName: "นาฬิกาหรู",
    imageUrl:
      "https://img13.360buyimg.com/imagetools/s100x100_jfs/t1/122338/17/8034/12430/5f1a50a3Ec3d71123/84f59b915f232b5b.png",
  },

  {
    displayName: "คำอวยพรวันเกิด",
    imageUrl:
      "https://m.360buyimg.com/da/s88x88_jfs/t1/81435/32/20228/6445/62bd2e5eE75b5e516/e30deb58d149febe.png.webp",
  },
  
];
