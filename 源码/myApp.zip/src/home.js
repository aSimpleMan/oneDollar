import React from "react"
import { Swiper } from '@nutui/nutui-react';
import { NavBar, Toast } from '@nutui/nutui-react';
import Language from './language'
import { NoticeBar } from '@nutui/nutui-react';
import { QuickEnter } from "@nutui/nutui-biz";
import  {quickEnterData}  from "./locales/zh-data.js";
import  {quickEnterData1}  from "./locales/thai-data.js";
import  {quickEnterData2}  from "./locales/en-data.js";
import { Divider } from '@nutui/nutui-react';
import { Price } from "@nutui/nutui-react";
import { ProductFeed } from "@nutui/nutui-biz";
import { useEffect, useState ,dispatch} from "react";
import "@nutui/nutui-biz/dist/styles/demo.css";
import "./main.css";
import { BASE_URL } from './config.js';
import axios from 'axios';
import { Progress, Cell } from '@nutui/nutui-react';
import {  CSSProperties } from "react";
import { ButtonProps } from "@nutui/nutui-react";
import { Coupon } from "@nutui/nutui-biz";
import { FormattedMessage  } from 'react-intl';
interface dataType {
  id: number,
  imgUrl: string,
  name: string,
  desc: string,
  tag: string | boolean,
  price: string,
  label: string,
  baifen:string
}
var text1;
var text2;
const App = () => {
    const [defaultValue1, setdefaultValue1] = useState(0);
    const [height, setHeight] = useState(180);
    const [data, setData] =  useState([]);
	const [shopDetail, setshopDetail] =  useState([]);
	const [listSingle, setListSingle] = useState([]);
    const [hasMoreSingle, setHasMoreSingle] = useState(true);
    const [daohangList, setDaohangList] = useState([]);
	
    useEffect(() => {
		var lan=localStorage.getItem("lang");
		switch (lan) {
		  case "zhTW":
		  text1="立即領取"
		  setBtnText(text1);
		  text2="領取完成"
		    setDaohangList(quickEnterData)
		    break;
		  case "thai":
		  text1="รับมันตอนนี้"
		  setBtnText(text1);
		  text2="ได้รับแล้ว"
			setDaohangList(quickEnterData1)
			break;
		  case "enUS":
		  text1="Receive"
		  setBtnText(text1);
		  text2="ReceiveD"
		    setDaohangList(quickEnterData2)
		    break;
		 default:
		 text1="立即領取"
		 setBtnText(text1);
		 text2="領取完成"
			setDaohangList(quickEnterData)
		}
      initData()
    }, [])
    const test = () => {
     console("test");
    }
    const init = () => {
      for (let i = 0; i < data.length; i++) {
        listSingle.push(data[i])
      }
      setListSingle([...listSingle])
    }
  
    const initData = () => {
		
		var token=localStorage.getItem("token");
		axios({
		      method: 'post',
			  withCredentials: true,
			  changeOrigin:true,
			  headers:{'Content-Type':'application/x-www-form-urlencoded'},
			  params:{
			  	'token':token
			  },
		      url: BASE_URL+'/api/good/activitylist'
		    }).then(response => {
			 
		      console.log(JSON.stringify(response.data))
		      if(response.status=='200'){
				var list=response.data.data.list;
				setshopDetail(list)
				for(var i = 0; i < list.length; i++) {
				  data.push({
				    id: i ,
				    imgUrl: BASE_URL+list[i].good_img1,
				    name: list[i].good_name1,
				    desc: list[i].good_name2,
				    tag: '标签标签',
				    price: list[i].price,
				    label: "热门",
					baifen:Number(100-list[i].join_count/list[i].set_ord*100)
				  })
				}
				init();
		  		}
		}).catch(()=>{});
      
      
    }
  
    const loadMore = (list: any) => {
     
    }
  
    const loadMoreSingle = (done: () => void) => {
     
    }
  
    const handleClick = (item: object, index: number) => {
      console.log("click", item, index)
	   console.log("shopDetail", shopDetail)
	   
	  
	  var obj=JSON.stringify(shopDetail[index])
	 localStorage.setItem("shopDetail",obj);
	
	  window.location.href="/shopDetail";
	 

	  
    }
  
    const handleImageClick = (item: object, index: number) => {
      console.log("click image", item, index)
    }
  
    const customProductSingle = (item: any) => {
		
      return (
        <>
          <div className="name-box">
            <div className="label">{item.label}</div>
            {item.name}
          </div>
		  <div className="name-box">
		  <div className="price">
		    <Price price={item.price} /><Price price={item.price+500} thousands line/>
		  </div>
		   
		  </div>
          
          <div className="bottom">
            <div className="price-box">
			<FormattedMessage id="home4" />
              <Cell>
                    <Progress percent={item.baifen} strokeWidth="5" showText />
                  </Cell>
            </div>
          </div>
        </>
      )
    }
	//------------------------优惠劵
    const buttonProps: Partial<ButtonProps> = React.useMemo(() => {
        return {
          type: "primary",
          size: "small",
          plain: true,
          className: "cancel-btn",
        };
      }, []);
    
      //已经使用的icon标记
      const usedIcon = React.useMemo(() => {
        return (
          <img
            src="https://storage.360buyimg.com/jdcdkh/open/1.0.0/assets/use-mask.60dc7c10.png"
            width="45px"
            height="42px"
          />
        );
      }, []);
      //渲染组件文案内容
      const baseCouponObj = React.useMemo(() => {
		  var lan=localStorage.getItem("lang");
		  switch (lan) {
		    case "zhTW":
		      return {
		        price: "200",
		        currency: "¥",
		        mainTitle: "滿1000元可用",
		        subTitle: "僅可購買滿折券測試",
		        label: <div style={{ color: "red" }}>新用戶專享</div>,
		        timeRange: "2023.10.01-2024.10.01",
		      };
		      break;
		    case "thai":
		  	return {
		  	  price: "200",
		  	  currency: "¥",
		  	  mainTitle: "สามารถสั่งซื้อได้ตั้งแต่1,000หยวนขึ้นไป",
		  	  subTitle: "ซื้อคูปองส่วนลดเต็ม",
		  	  label: <div style={{ color: "red" }}>สิทธิพิเศษสำหรับผู้ใช้ใหม่</div>,
		  	  timeRange: "2023.10.01-2024.10.01",
		  	};
		  	break;
		    case "enUS":
		      return {
		        price: "200",
		        currency: "¥",
		        mainTitle: "Available for orders over 1,000",
		        subTitle: "Only full discount coupons can be purchased",
		        label: <div style={{ color: "red" }}>Exclusive for new users</div>,
		        timeRange: "2023.10.01-2024.10.01",
		      };
		      break;
		   default:
		  	return {
		  	  price: "200",
		  	  currency: "¥",
		  	  mainTitle: "滿1000元可用",
		  	  subTitle: "僅可購買滿折券測試",
		  	  label: <div style={{ color: "red" }}>新用戶專享</div>,
		  	  timeRange: "2023.10.01-2024.10.01",
		  	};
		  }
        
      }, []);
      //优惠券样式
      const couponBaseStyle: CSSProperties = React.useMemo(() => {
        return {
          width: "100%",
          height: "auto",
          backgroundImage: `url(https://storage.360buyimg.com/jdcdkh/open/1.0.0/assets/bg-coupon-red.f6ae2e19.png)`,
        };
      }, []);
      //优惠券主体样式
      const couponMainBaseStyle: CSSProperties = React.useMemo(() => {
        return {
          width: "69%",
          color: "#fff",
        };
      }, []);
      //按钮文案
      const [btnText, setBtnText] = useState(text1);
      //是否点击了立即领取按钮
      const [receivedStatus, setReceivedStatus] = useState(false);
      const basedOnClick = React.useCallback(() => {
        setBtnText(text2);
        setReceivedStatus(true);
      }, [btnText, receivedStatus]);
      const demoStyle = {
        height: "100%",
        overflow: "auto",
        padding: "17px 17px 0 17px",
      };
	  
	  const onItem = (item: object, index: number) => {
	    console.log("click image", item, index)
	  }
  return (
  <div><NavBar
            
            right={
            <span >
                <Language />
            </span>
            }
            
        >
            <span>
            <FormattedMessage id="hello" />
            </span>
        </NavBar>
		<NoticeBar content={<FormattedMessage id="home1" />} />
    <div className="demo-box" style={{ height: 180 }}>
      <Swiper
        height={height}
        style={{
            '--nutui-indicator-color': '#426543',
            '--nutui-indicator-dot-color': '#426ddd',
          }}
        autoPlay="3000"
        defaultValue={defaultValue1}
        indicator
		loop={true}
      >
        <Swiper.Item >
          <img src="./1.jpg" alt="" />
        </Swiper.Item>
        <Swiper.Item >
          <img src="./2.jpg" alt="" />
        </Swiper.Item>
        <Swiper.Item >
          <img src="./3.jpg" alt="" />
        </Swiper.Item>
        <Swiper.Item >
          <img src="./4.jpg" alt="" />
        </Swiper.Item>
      </Swiper>
    </div>
	<div className="main-body">
		<Divider contentPosition="left"><FormattedMessage id="home2" /></Divider>
		
		<QuickEnter onClick={(e) =>  window.location.href="/shop"} onClickItem={onItem} data={daohangList} />
		<Divider contentPosition="left"><FormattedMessage id="home3" /></Divider>
		<div style={demoStyle}>
		      <Coupon
		        pricePosition="back"
		        couponStyle={couponBaseStyle}
		        couponMainStyle={couponMainBaseStyle}
		        couponData={baseCouponObj}
		        btnText={btnText}
		        isReceived={receivedStatus}
		        usedIcon={usedIcon}
		        buttonProps={buttonProps}
		        onBtnClick={basedOnClick}
		      ></Coupon>
		    </div>
		<div className="demo product-feed-demo">
	
	      <ProductFeed
		    
	        className="product-feed-demo2"
	        data={listSingle}
	        infiniteloadingProps={{
	          hasMore: hasMoreSingle,
	          onLoadMore: loadMoreSingle
	        }}
	        customProduct={customProductSingle}
	        col={1}
	        imgUrl="imgUrl"
	        imgWidth="100"
	        imgHeight="100"
	        imgTag={<div className="img-label"><img src="https://img12.360buyimg.com/imagetools/jfs/t1/186347/7/7338/1009/60c0806bE0b6c7207/97fd04b48d689ffe.png" /></div>}
	        onClick={handleClick}
	        onImageClick={handleImageClick}
	      />
	    </div>
	</div>
    </div>
  )
}
export default App;
