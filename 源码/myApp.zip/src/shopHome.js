import  React,{useEffect,useState} from 'react';
import { NavBar, Toast,Notify } from '@nutui/nutui-react';
import Language from './language';
import { ProductFeed } from "@nutui/nutui-biz";
import { BASE_URL } from './config.js';
import axios from 'axios';
import { Price ,Progress, Cell } from "@nutui/nutui-react";
import { FormattedMessage  } from 'react-intl';
import "./main.css";
export default function OrderList() {
	const [listSingle, setListSingle] = useState([]);
	 const [hasMoreSingle, setHasMoreSingle] = useState(true);
	 const [data, setData] =  useState([]);
	 const [shopDetail, setshopDetail] =  useState([]);
	const getData = () => {
		var token=localStorage.getItem("token");
		axios({
		      method: 'post',
			  withCredentials: true,
			  changeOrigin:true,
			  headers:{'Content-Type':'application/x-www-form-urlencoded'},
			  params:{
			  	'token':token
			  },
		      url: BASE_URL+'/api/good/activitylist'
		    }).then(response => {
			 
		      console.log(JSON.stringify(response.data))
		      if(response.status=='200'){
				var list=response.data.data.list;
				setshopDetail(list)
				for(var i = 0; i < list.length; i++) {
				  data.push({
				    id: i ,
				    imgUrl: BASE_URL+list[i].good_img1,
				    name: list[i].good_name1,
				    desc: list[i].good_name2,
				    tag: '标签标签',
				    price: list[i].price,
				    label: "热门",
					baifen:Number(100-list[i].join_count/list[i].set_ord*100)
				  })
				}
				init();
		  		}
		});
		      
		
	  };
    
    useEffect(() => {
        getData();
      }, []);
    const init = () => {
      for (let i = 0; i < data.length; i++) {
        listSingle.push(data[i])
      }
      setListSingle([...listSingle])
    }
    const loadMore = (list: any) => {
     
    }
      
    const loadMoreSingle = (done: () => void) => {
     
    }
	const handleClick = (item: object, index: number) => {
	  console.log("click", item, index)
	   console.log("shopDetail", shopDetail)
	   
	  
	  var obj=JSON.stringify(shopDetail[index])
	 localStorage.setItem("shopDetail",obj);
	
	  window.location.href="/shopDetail";
	 
	
	  
	}
	  
	const handleImageClick = (item: object, index: number) => {
	  console.log("click image", item, index)
	}
	  
	const customProductSingle = (item: any) => {
		
	  return (
	    <>
	      <div className="name-box">
	        <div className="label">{item.label}</div>
	        {item.name}
	      </div>
		  <div className="name-box">
		  <div className="price">
		    <Price price={item.price} /><Price price={item.price+500} thousands line/>
		  </div>
		   
		  </div>
	      
	      <div className="bottom">
	        <div className="price-box">
			<FormattedMessage id="home4" />
	          <Cell>
	                <Progress percent={item.baifen} strokeWidth="5" showText />
	              </Cell>
	        </div>
	      </div>
	    </>
	  )
	}
    return (
	<div>
        <NavBar
            
            right={
            <span >
                <Language />
            </span>
            }
            onBackClick={(e) =>  Toast.show("返回")}
        >
            <span onClick={(e) =>  Toast.show("标题")}>
            <FormattedMessage id="top1" />
            </span>
        </NavBar>
		<div className="demo product-feed-demo">
			
		  <ProductFeed
		    
		    className="product-feed-demo2"
		    data={listSingle}
		    infiniteloadingProps={{
		      hasMore: hasMoreSingle,
		      onLoadMore: loadMoreSingle
		    }}
		    customProduct={customProductSingle}
		    col={1}
		    imgUrl="imgUrl"
		    imgWidth="100"
		    imgHeight="100"
		    imgTag={<div className="img-label"><img src="https://img12.360buyimg.com/imagetools/jfs/t1/186347/7/7338/1009/60c0806bE0b6c7207/97fd04b48d689ffe.png" /></div>}
		    onClick={handleClick}
		    onImageClick={handleImageClick}
		  />
		</div>
		</div>
		
    )
}

