import React from "react";
import Layout from './Layout'
import Login from './login'
import Register from './register'
import OrderList from './orderList'
import Shop from './shopList'
import Home from './home'
import My from './my'
import ShopDetail from './shopDetail'
import MoneyChangeList from './moneyChangeList'
import Message from './message'
import ShopHome from './shopHome'


// 导入路由
import { HashRouter, BrowserRouter, Routes, Route } from 'react-router-dom'
// 配置路由规则
function App() {
  return (
    <BrowserRouter>
      <Routes> 
        <Route path="/" element={<Layout />}>    // 必须要有根路径
           
           <Route path="/home" element={<Home />} ></Route>
		   <Route path="/shop" element={<Shop />}></Route> 
		   <Route path="/my" element={<My />}></Route> 
		   <Route path="/shopHome" element={<ShopHome />}></Route> 
		   <Route path="/OrderList" element={<OrderList />} ></Route>
        </Route>
        <Route path="/login" element={<Login />} ></Route>
		<Route path="/register" element={<Register />} ></Route>
		<Route path="/shopDetail" element={<ShopDetail />}></Route> 
		
		<Route path="/moneyChangeList" element={<MoneyChangeList />} ></Route>
		<Route path="/message" element={<Message />} ></Route>
		
      </Routes>
    </BrowserRouter >
  )
}

export default App;