import  React, { useState  } from "react";
import { Picker } from '@nutui/nutui-react';

const App = () => {
  const [visible, setVisible] = useState(false)
  const [baseDesc, setBaseDesc] = useState('')
  
  const listData1 = [
    [
      { value: 1, text: '繁体中文',},
      { value: 2, text: 'ภาษาไทย',},
      { value: 3, text: 'English',},
      
    ],
  ]
  
  const changePicker = (list: any[], option: any, columnIndex: number) => {
	
	if(option[0]==1){
		console.log("11")
		localStorage.setItem("lang",'zhTW');
	}else if(option[0]==2){
		localStorage.setItem("lang",'thai');
		console.log("22")
	}else if(option[0]==3){
		localStorage.setItem("lang",'enUS');
		console.log("33")
	}
	
    //var lan=localStorage.getItem("lang");
	
  }
  const confirmPicker = (options: PickerOption[], values: (string | number)[]) => {
    let description = ''
    options.forEach((option: any) => {
      description += option.text
    })
    setBaseDesc(description)
	window.location.href="";
  }
  return ( 
       <>
      <img class="dark-model" src="./language.png" title="切换语言" description={baseDesc} onClick={() => setVisible(!visible)}/>
		
      <Picker
        visible={visible}
        options={listData1}
        onConfirm={(list, values) => confirmPicker(list, values)}
        onClose={() => setVisible(false)}
        onChange={changePicker}
       />
	   
	   
    </>
	
  );
};  
export default App;
